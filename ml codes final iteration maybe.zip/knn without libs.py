import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

df = pd.read_csv("123.csv")

X = df.iloc[:, :-1]
y = df.iloc[:, -1]

# Encode labels
labels = np.unique(y)
y = np.array([np.where(labels == v)[0][0] for v in y])

# Train-Test Split
Xtr, Xt, ytr, yt = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Scaling
sc = StandardScaler()

Xtr = sc.fit_transform(Xtr)
Xt = sc.transform(Xt)


def knn_predict(x, k):
    dist = np.sqrt(np.sum((Xtr - x) ** 2, axis=1))
    idx = np.argsort(dist)[:k]
    values = ytr[idx]
    return np.bincount(values).argmax()


for k in [3, 5, 7]:

    pred = np.array([knn_predict(x, k) for x in Xt])

    print("K =", k)
    print("Actual   :", yt)
    print("Predicted:", pred)
    print("Accuracy :", accuracy_score(yt, pred))